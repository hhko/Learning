﻿namespace LogViewer.Server.Models
{
    public class LogTemplate
    {
        public string MessageTemplate { get; set; }

        public int Count { get; set; }
    }
}
