angular.module("logViewerApp").component("loader", {
    templateUrl: "components/loader.html",
});
