﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Datalust.ClefTool.Tests")]
